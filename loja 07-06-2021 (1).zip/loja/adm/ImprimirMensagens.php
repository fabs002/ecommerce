<?php

    require_once 'dompdf/autoload.inc.php';

    use Dompdf\Dompdf;

    $dompdf = new Dompdf();

include "conexao.php";

         try

         {
         	$MatrizClientes = $conexao->prepare("SELECT * FROM  mensagem ORDER BY idMsg ASC;");
         	$MatrizClientes->execute();

         	$Relat = '';
         	$Relat .= '<table >';
         	$Relat .= '<tr>';
         	$Relat .= '<th> ID </th>';
         	$Relat .= '<th> Nome </th>';
         	$Relat .= '<th> Email </th>';
         	$Relat .= '<th> Telefone </th>';
            $Relat .= '<th> Assunto </th>';
         	$Relat .= '<th> Mensagem </th>';
         	$Relat .= '</tr>';

         	while ($Linha = $MatrizClientes->fetch(PDO::FETCH_OBJ)) 
         	{
         		$Relat .= '<tr>';
         		     $Relat .= '<td>' . $Linha->idMsg . '</td>';
         		     $Relat .= '<td>' . $Linha->nome . '</td>';
         		     $Relat .= '<td>' . $Linha->email . '</td>';
         		     $Relat .= '<td>' . $Linha->telefone . '</td>';
         		     $Relat .= '<td>' . $Linha->assunto . '</td>';
                     $Relat .= '<td>' . $Linha->msg . '</td>';
         		$Relat .= '</tr>';
         	}

         	    $Relat .= '</table>';

            
         	$dompdf->load_Html('<h1 style="text-align: center;">Relatorio de Clientes</h1>' . $Relat );

         	$dompdf->setPaper('A4', 'portrait');

         	$dompdf->render();

         	$dompdf->stream("relatorio.pdf", array("Attachment" => false)); 

         }
         catch (PDOException $erro) 
         {
         	echo "Erro: ".$erro->getMessage();
         }
?>