<?php

include "conexao.php";

$nome         = $_POST['nomeProduto'];
$codigo       = $_POST['codProduto'];
$categoria    = $_POST['catProduto'];
$quantidade   = $_POST['quantProduto'];
$valor        = $_POST['valorProduto'];
$descricao    = $_POST['descProduto'];
$botao        = $_POST['Cadastrar'];

//------------- Upload de fotos -----------------

$arquivoAtual = $_FILES['arquivo']['name'];
$arquivoTmp   = $_FILES['arquivo']['tmp_name'];
$destino      = 'IMG/' . $arquivoAtual;


//------------- Cadastro do Produto -------------
try
{

    if($botao == 'Cadastrar'){

        move_uploaded_file($arquivoTmp, $destino);

        $comando=$conexao->prepare("INSERT INTO produto (NomeProduto,CodProduto,catProduto,Quant,ValorProduto,DescricaoProduto,imgProduto) VALUES (?, ?, ?, ?, ?, ?, ?)");

        $comando->bindParam(1, $nome);
        $comando->bindParam(2, $codigo);
        $comando->bindParam(3, $categoria);
        $comando->bindParam(4, $quantidade);
        $comando->bindParam(5, $valor);
        $comando->bindParam(6, $descricao);
        $comando->bindParam(7, $arquivoAtual);

        
        $comando->execute();
        
        if($comando->rowCount() > 0)

        {
            
            $RetornoMensagem = '<SCRIPT>
                                window.alert("Cadastro efetuado com sucesso!")
                                window.location.href="produtos.php"</SCRIPT>';

        }
        else
        {
            $RetornoMensagem = '<script> alert("Produto nao cadastrado!")</script>';
        }
    }
    
}
catch(PDOException $erro)
{
    $RetornoMensagem = "Erro: " . $erro->getMessage();
}
echo $RetornoMensagem;

?>