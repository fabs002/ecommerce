<!DOCTYPE html>
<html>
<head>
	
	<script src="../js/scripts.js"></script>
		<link rel="icon" href="../IMG/favicon.ico">
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
		<meta http-equiv="refresh" content="5;url=index.php"> 
		<title>
		Area restrita
		</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
		<link rel="stylesheet" href="../CSS/new.css">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</head>
<body>
	<img class="mx-auto d-block" src="IMG/erro.png" width="350px" height="300">
	<p class="text-center">Para ter acesso ao conteúdo, você deverá efetuar seu login e senha. </p>
	<p class="text-center">Você será redirecionado em 5 segundos. </p>
	
</body>
</html>