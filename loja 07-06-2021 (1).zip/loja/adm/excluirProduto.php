<?php

include "conexao.php";

$idProduto = $_GET['id'];

$matriz = $conexao->prepare("DELETE FROM produto WHERE idProduto = ?");
$matriz->bindParam(1, $idProduto);
                        
$matriz->execute();

echo '<SCRIPT>window.alert("Produto excluido com sucesso!")
              window.location.href="listaProdutos.php"</SCRIPT>';


?>