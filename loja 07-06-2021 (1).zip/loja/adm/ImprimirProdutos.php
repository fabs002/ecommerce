<?php

    require_once 'dompdf/autoload.inc.php';

    use Dompdf\Dompdf;

    $dompdf = new Dompdf();

include "conexao.php";

         try

         {
         	$MatrizClientes = $conexao->prepare("SELECT * FROM  produto ORDER BY idProduto ASC;");
         	$MatrizClientes->execute();

         	$Relat = '';
         	$Relat .= '<table >';
         	$Relat .= '<tr>';
         	$Relat .= '<th cope="col"> ID </th>';
         	$Relat .= '<th> Nome </th>';
         	$Relat .= '<th> Codigo </th>';
         	$Relat .= '<th> Categoria </th>';
            $Relat .= '<th> Quantidade </th>';
         	$Relat .= '<th> Valor </th>';
         	$Relat .= '</tr>';

         	while ($Linha = $MatrizClientes->fetch(PDO::FETCH_OBJ)) 
         	{
         		$Relat .= '<tr>';
         		     $Relat .= '<td>' . $Linha->idProduto . '</td>';
         		     $Relat .= '<td>' . $Linha->NomeProduto . '</td>';
         		     $Relat .= '<td>' . $Linha->CodProduto . '</td>';
         		     $Relat .= '<td>' . $Linha->catProduto . '</td>';
         		     $Relat .= '<td>' . $Linha->Quant . '</td>';
                    $Relat .= '<td>' . $Linha->ValorProduto . '</td>';
         		$Relat .= '</tr>';
         	}

         	    $Relat .= '</table>';

            
         	$dompdf->load_Html('<h1 style="text-align: center;">Relatorio de Clientes</h1>' . $Relat );

         	$dompdf->setPaper('A4', 'portrait');

         	$dompdf->render();

         	$dompdf->stream("relatorio.pdf", array("Attachment" => false)); 

         }
         catch (PDOException $erro) 
         {
         	echo "Erro: ".$erro->getMessage();
         }
?>