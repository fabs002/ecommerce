<?php

include "conexao.php";

$idProduto    = $_POST['idProduto'];
$nome         = $_POST['nomeProduto'];
$codigo       = $_POST['codProduto'];
$categoria    = $_POST['catProduto'];
$quantidade   = $_POST['quantProduto'];
$valor        = $_POST['valorProduto'];
$descricao    = $_POST['descProduto'];



//------------- Upload de fotos -----------------

$arquivoAtual = $_FILES['arquivo']['name'];
$arquivoTmp   = $_FILES['arquivo']['tmp_name'];
$destino      = 'IMG/' . $arquivoAtual;


//------------- Cadastro do Produto -------------



        move_uploaded_file($arquivoTmp, $destino);

        $buscaImg=$conexao->prepare("SELECT imgProduto 
                                     FROM produto 
                                     WHERE  idProduto = '$idProduto';");
        $buscaImg->execute();

        $linha = $buscaImg->fetch(PDO::FETCH_OBJ);

        if($arquivoAtual == false)
        {

        $comando=$conexao->prepare("UPDATE  produto 
                                    SET     NomeProduto = ?, 
                                            CodProduto = ?,
                                            catProduto = ?,
                                            Quant = ? ,
                                            ValorProduto = ?,
                                            DescricaoProduto = ?,
                                            imgProduto = ?
                                    WHERE   idProduto = '$idProduto';");

        $comando->bindParam(1, $nome);
        $comando->bindParam(2, $codigo);
        $comando->bindParam(3, $categoria);
        $comando->bindParam(4, $quantidade);
        $comando->bindParam(5, $valor);
        $comando->bindParam(6, $descricao);
        $comando->bindParam(7, $linha->imgProduto);


        $comando->execute();
        
       echo'<SCRIPT>
            window.alert("Produto atualizado")
            window.location.href="editarProduto.php?id='.$idProduto.'"
            </SCRIPT>';
        }else{
            $comando=$conexao->prepare("UPDATE  produto 
                                        SET     NomeProduto = ?, 
                                                CodProduto = ?,
                                                catProduto = ?,
                                                Quant = ? ,
                                                ValorProduto = ?,
                                                DescricaoProduto = ?,
                                                imgProduto = ?
                                        WHERE   idProduto = '$idProduto';");

        $comando->bindParam(1, $nome);
        $comando->bindParam(2, $codigo);
        $comando->bindParam(3, $categoria);
        $comando->bindParam(4, $quantidade);
        $comando->bindParam(5, $valor);
        $comando->bindParam(6, $descricao);
        $comando->bindParam(7, $arquivoAtual);

        
        $comando->execute();
        
       echo'<SCRIPT>
            window.alert("Produto atualizado")
            window.location.href="editarProduto.php?id='.$idProduto.'"
            </SCRIPT>';
        }

?>