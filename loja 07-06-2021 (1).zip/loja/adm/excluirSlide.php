<?php

include "conexao.php";

$idImagem = $_GET['id'];

$matriz = $conexao->prepare("DELETE FROM slide WHERE idImagem = ?");
$matriz->bindParam(1, $idImagem);
                        
$matriz->execute();

echo '<SCRIPT>window.alert("Slide excluido com sucesso!")
              window.location.href="CadSlide.php"</SCRIPT>';


?>